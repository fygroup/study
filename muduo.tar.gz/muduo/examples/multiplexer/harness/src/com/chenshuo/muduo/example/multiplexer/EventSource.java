package com.chenshuo.muduo.example.multiplexer;

public enum EventSource {
    kBackend, kClient
}
